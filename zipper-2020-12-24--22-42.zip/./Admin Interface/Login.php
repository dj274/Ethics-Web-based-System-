<?php
 session_start();
	require('../db.php');
	
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){

		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($conn,$username); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($conn,$password);
 
	//Checking is user existing in the database or not
    $query = "SELECT * FROM `users` WHERE UserId='$username' and password='".md5($password)."'";
		$result = mysqli_query($conn,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
    
    if($rows==1){
      if($rows= $result->fetch_assoc()){
       
          if($rows["acc_type"]=="Admin"){
            header("Location: AdminDashboard.php"); // Redirect user to Admin dashboard
          }else if($rows["acc_type"]=="applicant"){
            header("Location: Applicant Dashboard.php"); // Redirect user to Admin dashboard
          }else if($rows["acc_type"]=="Ethics committee"){
            header("Location: Ethics Dashboard.php"); // Redirect user to dashboard
          }
        }
        
    }else{
    echo "<div class='pageButtons'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
    }
  }
?>

<!DOCTYPE html>
<html>

<head>
   <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Sign in
</title>

</head>

<body>

  <h1>
    Sign in
  </h1>


<form action= "" method="post">
  <div class="LoginContainer">
    <label for="username"><b>Username</b</label>
    <input type= "text" placeholder="eg ab123" name="username" required>
    <span class="psw"><a href="#">I've forgotten my username</a></span>

    <br><br>

    <label for="password"><b>Password</b</label>
    <input type= "password" placeholder="Enter password" name="password" required>
    <span class="psw"><a href="#">I've forgotten my password</a></span>


    <div class="pageButtons">
      <button type="submit" class="nextbtn1">Login</button>

<br>

      <span class="psw">New User: <a href="#">Click here to activite your account</a></span>

    </div>
</div>
</form>
</body>
</html>
