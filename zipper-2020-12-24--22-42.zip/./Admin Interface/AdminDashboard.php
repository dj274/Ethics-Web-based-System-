<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>
<title>
Home
</title>

</head>

<body>

  <h1>
    Users
  </h1>
  <br>
  <br>
  <br>
  <div>

    <table>
      <tr>
        <th>UserID</th>
        <th>Email Address</th>
        <th>Password</th>
        <th>Department</th>
        <th>Account type</th>
        <th>Actions</th>
      </tr>
    </table>

</form>
</body>
</html>
