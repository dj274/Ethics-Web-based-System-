><?php

require("../db.php");

  if (isset($_REQUEST['FullName'])){
    
		$fullname = stripslashes($_REQUEST['FullName']); // removes backslashes
    $fullname = mysqli_real_escape_string($conn,$fullname); //escapes special characters in a string
    $email = stripslashes($_REQUEST['Email']); // removes backslashes
		$email = mysqli_real_escape_string($conn,$email);
		$userID = stripslashes($_REQUEST['UserID']);
		$userID = mysqli_real_escape_string($conn,$userID);
		$password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($conn,$password);
    $role = stripslashes($_REQUEST['Role']);
    $role = mysqli_real_escape_string($conn,$role);
    $department = stripslashes($_REQUEST['Department']);
    $department = mysqli_real_escape_string($conn,$department);
        
		$trn_date = date("Y-m-d H:i:s");
               $query = "INSERT into `users` (FullName, email, UserId, acc_type, Department,password) VALUES ('$fullname','$email','$userID', '$role','$department','".md5($password)."')";

        $result = mysqli_query($conn,$query);
        if($result){
            echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
        }else{
            echo "Registration unsuccessful";
        }
    }else{
}
?>
<!DOCTYPE html>
<html>
    
<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>
    
<title>
  User Assigning Accounts
</title>

</head>

<body>

  <h1>
    User Assigning Accounts
  </h1>


<form action= "" method="post">
  <div class="LoginContainer">

    <label for="uname"><b>Full Name</b</label>
    <input type= "text" placeholder="Full Name" name="FullName" required>

    <label for="uname"><b>Kent(ID) Email</b</label>
    <input type= "text" placeholder="ab123@kent.ac.uk" name="Email" required>

    <label for="uname"><b>User ID</b</label>
    <input type= "text" placeholder="User ID" name="UserID" required>

  <label for="Role"><b>Assign Role </b</label>
  <select id="Department" name="Role"required>
  <option value="">Please choose an option</option>
  <option value="Applicant">Applicant</option>
  <option value="Ethics Commitee">Ethics Commitee</option>
  <option value="Reviewer">Reviewer</option>
  <option value="Admin">Admin</option>
</select>
<label for="Department"><b>Assign Department</b</label>
  <select id="Department" name="Department"required>
  <option value="">Please choose an option</option>
  <option value="Computing">Computing</option>
  <option value="Economics">Economics</option>
  <option value="Business">Business</option>
  <option value="Arts">Arts</option>
</select>

    <label for="psw"><b>Create Password</b</label>
    <input type= "password" placeholder="Password" name="password" required>

    <label for="psw"><b>Confirm Password</b</label>
    <input type= "password" placeholder="Confirm password" name="confirm_password" required>


    <div class="pageButtons">
      <button type="submit" class="nextbtn1">Confirm</button>
    </div>
  </div>
</form>
</body>
</html>
