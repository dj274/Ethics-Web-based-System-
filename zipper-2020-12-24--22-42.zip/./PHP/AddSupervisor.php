<?php

session_start();

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$SupervisorName = $_POST['SupervisorName'];
$SupervisorEmail = $_POST['SupervisorEmail'];
$ApplicationID = $_SESSION["ApplicationID"];

$sql = "INSERT INTO Section3_Declaration (SupervisorName, SupervisorEmail, ApplicationID)
VALUES ('$SupervisorName', '$SupervisorEmail', $ApplicationID)";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>
<script type="text/javascript">
window.location.href = '../Applicant Interface/P4_Section3Declaration&Signatures.php';
</script>

