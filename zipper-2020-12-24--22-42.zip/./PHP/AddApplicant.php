<?php

session_start();

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$Name = $_POST['ApplicantName'];
$Department = $_POST['School/Department'];
$Email = $_POST['email'];
$Phone = $_POST['phone'];
$Postcode = $_POST['Postcode'];
$Address = $_POST['Address'];
$Study = $_POST['Study'];
$ApplicationID = $_SESSION["ApplicationID"];

$sql = "INSERT INTO Section2_Applicant_Details (ApplicantName, Department, Email, Telephone, Postcode, Address, Study, ApplicationID)
VALUES ('$Name', '$Department', '$Email', '$Phone', '$Postcode', '$Address', '$Study', $ApplicationID)";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>
<script type="text/javascript">
window.location.href = '../Applicant Interface/P3_Section2ApplicantDetails.php';
</script>