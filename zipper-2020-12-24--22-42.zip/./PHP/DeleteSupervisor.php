<?php

$id = $_GET['id'];
$nextpage = urldecode($_GET['next']);

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "DELETE FROM Section3_Declaration WHERE SupervisorID=" . $id;

if (mysqli_query($conn, $sql)) {
  echo "Record deleted successfully";

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>
<script type="text/javascript">
window.location.href = "../" + "<?php echo $nextpage ?>";
</script>