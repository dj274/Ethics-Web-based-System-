function saveData(nextPage)
{
    var inputs = document.getElementsByTagName('input');

    var dict = {};

    for(var i = 0; i < inputs.length; i++) {
        dict[encodeURIComponent(inputs[i].id)] = encodeURIComponent(inputs[i].value);
    }

    var oldurl = document.location.href.split('?')[1];
    var url = nextPage + '?';

    if (oldurl != undefined)
    {
      url += oldurl + "&";
    }

    for (var key in dict)
    {
      url += key + "=" + dict[key] + "&";
    }

        console.log(url);

    document.location.href = url;
}

function clearInputs()
{
  var inputs = document.getElementsByTagName('input');

  for(var i = 0; i < inputs.length; i++) {
    inputs[i].value = "";

    if(inputs[i].type.toLowerCase() == 'checkbox') {
      if (inputs[i].id != "agreeterms:")
      {
        inputs[i].checked = false;
        inputs[i].setAttribute("required", true)
      }
    }
  }
}

function manageTextArea(yesorno, answerID)
{

  if (yesorno)
  {
        document.getElementById(answerID).style.display = "block";
  }
  else {
      document.getElementById(answerID).style.display = "none";
  }
}

window.onload = function () {
    var url = document.location.href;

    if (url.split('?')[1] != undefined)
    {
      var params = url.split('?')[1].split('&');
      var data = {};
      var tmp;

      for (var i = 0; i < params.length; i++) {
          if (params[i] != undefined)
          {
            tmp = params[i].split('=');
            data[tmp[0]] = tmp[1];
          }
      }
    }
}

function getMinDate()
{
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth()+1; //January is 0!
  var yyyy = today.getFullYear();
   if(dd<10){
          dd='0'+dd
      }
      if(mm<10){
          mm='0'+mm
      }

  today = yyyy+'-'+mm+'-'+dd;
  document.getElementById("planned start date").setAttribute("min", today);
}

function getMinDateEnd(e)
{
  //alert(e.target.value);

  var minDate = new Date(e.target.value);

  minDate.setDate(minDate.getDate()+1);

  console.log(String(minDate.getMonth()+1));


  var today = minDate.getFullYear() + "-" + String("0" + (minDate.getMonth()+1)).slice(-2) + "-" + String("0" + minDate.getDate()).slice(-2);

  console.log(e.target.value);
  console.log(today);
  document.getElementById("planned end date").setAttribute("min", today);
}

function currCheck(name)
{
  currentBox = document.getElementById(name.target.id);

  var inputs = document.getElementsByTagName('input');

    for(var i = 0; i < inputs.length; i++) {
        if(inputs[i].type.toLowerCase() == 'checkbox') {
          if (inputs[i].id == currentBox.id)
          {
            if (inputs[i].value != name.target.value)
            {
              inputs[i].removeAttribute("required")
              inputs[i].checked = false;
            }
            else {
              inputs[i].setAttribute("required", true)
            }
          }
        }
    }
}
