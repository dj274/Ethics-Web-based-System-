<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Sign in
</title>

</head>

<body>

  <h1>
    Sign in
  </h1>


<form action= "Page 3.html">
  <div class="LoginContainer">
    <label for="uname"><b>Username</b</label>
    <input type= "text" placeholder="eg ab123" name="uname" required>
    <span class="psw"><a href="#">I've forgotten my username</a></span>

    <br><br>

    <label for="psw"><b>Password</b</label>
    <input type= "password" placeholder="Enter password" name="psw" required>
    <span class="psw"><a href="#">I've forgotten my password</a></span>


    <div class="pageButtons">
      <button type="submit" class="nextbtn1">Login</button>

<br>

      <span class="psw">New User: <a href="#">Click here to activite your account</a></span>

    </div>
</div>
</html>

