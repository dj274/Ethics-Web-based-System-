<?php

session_start();
$ApplicationID = $_SESSION["ApplicationID"];
require('../db.php');

if(isset($_POST['q1'])){
$q1 = $_POST['q1'];
$q2 = $_POST['q2'];
$q3 = $_POST['q3'];
$ApplicationID = $_SESSION["ApplicationID"];

$sql = "INSERT INTO Full_Section4_Confidentiality (Q1, Q2, Q3, ApplicationID)
VALUES ('$q1', '$q2', '$q3', $ApplicationID)";
$result = mysqli_query($conn,$sql);
  if($result){
     header("Location:Page 11 Full Ethics Form.php");
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 4: Confidentiality
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active"></span>
      <span class="dash active"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
    </div>

<form action= "P14_Section5Incentives&Payments.php">
  <div class="container">
    <p><label for="apn"><b>
      In this section personal data means any data relating to a participant who could potentially be identified.  It includes pseudonymised data capable of being linked to a participant through a unique code number.
      If you will be undertaking any of the following activities at any stage (including in the identification of potential participants) please give details and explain the safeguarding measures you will employ
      <ul>
         <li>Electronic transfer by magnetic or optical media, email or computer networks</li>
        <li>Sharing of personal data outside the European Economic Area</li>
        <li>Use of personal addresses, postcodes, faxes, emails or telephone numbers</li>
        <li>Publication of direct quotations from respondents</li>
        <li>Publication of data that might allow identification of individuals, either directly or indirectly</li>
        <li>Use of audio/visual recording devices</li>
        <li>Storage of personal data on any of the following:</li>
      </ul>
      <d1>
        <dd> - Manual files</dd>
        <dd> - University computers</dd>
        <dd> - Home or other personal computers</dd>
        <dd> - Private company computers</dd>
        <dd> - Laptop computers</dd>
      </d1>
    </p>
    
    </b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>How will you ensure the confidentiality of personal data?  (eg, anonymisation or pseudonymisation of data)</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>Who will have access to participants’ personal data during the study?</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>How long will personal data be stored or accessed after the study has ended?  (If longer than 12 months, please justify)</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>
    
        <p>
      Please note:  as best practice, and as a requirement of many funders, where practical, researchers must develop a data management and sharing plan to enable the data to be made available for re-use, eg, for secondary research, and so sufficient metadata must be conserved to enable this while maintaining confidentiality commitments and the security of data.
    </p>

    <br>


  <div class="pageButtons">
    <a href="P12_Section3Recruitment&InformedConsent.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Next</button>
  </div>
</div>

</form>
</body>
</html>

