<?php
session_start();
$ApplicationID = $_SESSION["ApplicationID"];

?>


<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>
  <h1>
    Section 2: Applicant details
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active"></span>
      <span class="dash active"></span>
      <span class="step"></span>
      <span class="dash"></span>
      <span class="step"></span>

      <span class="dash"></span>
      <span class="step"></span>
      <span class="dash"></span>
      <span class="step"></span>
      <span class="dash"></span>
      <span class="step"></span>
    </div>

<form action="../PHP/AddApplicant.php" method="post">
  <div class="container">
    <label for="apn"><b>Applicant name:</b></label>
    <input type= "text" placeholder="Applicant name..." name="ApplicantName" id="applicant name" required>

    <label for="s/d"><b>School/Department:</b></label>
    <input type= "text" placeholder="School/Department..." name="School/Department" id="School/Department" required>

    <label for="email"><b>Kent(ID) Email:</b></label>
    <input type= "text" placeholder="Email..." name="email" id="email" required>

    <label for="phone"><b>Telephone:</b></label>
    <input type= "text" placeholder="Phone Number..." name="phone" id="phone" required>

    <label for="address"><b>Postcode:</b></label>
    <input type= "text" placeholder="Postcode" name="Postcode" id="postcode" required>

    <label for="address"><b>Address:</b></label>
    <input type= "text" placeholder="Postcode" name="Address" id="address" required>
    
    <label for="Study"><b>Level of Study/Staff</b</label>
      <select id="Study" name="Study" required>
      <option value="">Please choose an option</option>
      <option value="Undergraduate">Undergraduate</option>
      <option value="Taught Postgraduate">Taught Postgraduate</option>
      <option value="Research Postgraduate">Research Postgraduate</option>
      <option value="Staff">Staff</option>
    </select>


    <br> 

  <div class="pageButtons">
    <a href="P2_Section1ProjectDetails.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Add other Applicant</button>
  </div>
</div>

</form>



<?php
$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM Section2_Applicant_Details WHERE ApplicationID=" . $ApplicationID . " ORDER BY ApplicationID ASC LIMIT 1, 18446744073709551615";

if (mysqli_query($conn, $sql)) {
  $result = mysqli_query($conn, $sql);

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>

<table class="applicants">
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Department</th>
    <th>Email</th>
    <th>Telephone</th>
    <th>Postcode</th>
    <th>Address</th>
    <th>Study</th>
    <th>Delete</th>
  </tr>
      
<?php 
 
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>". $row["ApplicantID"]."</td>";
        echo "<td>". $row["ApplicantName"]."</td>";
        echo "<td>". $row["Department"]."</td>";
        echo "<td>". $row["Email"]."</td>";
        echo "<td>". $row["Telephone"]."</td>";
        echo "<td>". $row["Postcode"]."</td>";
        echo "<td>". $row["Address"]."</td>";
        echo "<td>". $row["Study"]."</td>";
        
        $nextPage = urlencode("Applicant Interface/P3_Section2ApplicantDetails.php");

        
        echo "<td><a href='../PHP/DeleteApplicant.php?id=".$row["ApplicantID"]."&next=$nextPage'> <img alt='https://www.flaticon.com/free-icon/delete_1345874?term=delete&page=1&position=3&related_item_id=1345874' src='https://www.flaticon.com/svg/static/icons/svg/1345/1345874.svg' width='20' height='20'></a></td>";
    }
?>

</table>

</body>
</html>