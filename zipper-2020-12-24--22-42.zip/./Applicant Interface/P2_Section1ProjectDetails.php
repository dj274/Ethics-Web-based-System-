
<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>
<title>
Form
</title>

</head>

<body onload="getMinDate()">

  <h1>
    Section 1: Project details
  </h1>


  <div style="text-align:center;margin-top:30px;">
    <span class="step active"></span>
    <span class="dash active"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>

    <span class="dash"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>

  </div>

<form action="../PHP/AddApplication.php" method="post">
  <div class="container">
    <label for="ptitle"><b>Project title:</b</label>
    <input type= "text" placeholder="Project title..." name="ProjectTitle" id="project title" required>

    <label for="psd"><b>Planned start date:</b</label>
    <input type= "date" name="PlannedStartDate" id="planned start date" onchange="getMinDateEnd(event);" required>

    <label for="ped"><b>Planned end date:</b</label>
    <input type= "date" name="PlannedEndDate" id="planned end date" required>

    <label for="fund"><b>Funder:</b</label>
    <input type= "text" placeholder="Funder..." name="Funder" id="fund" required>

    <div class="pageButtons">
      <button type="submit" class="nextbtn1">Next</button>
    </div>
</div>
</form>
</body>
</html>


