<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>
<title>
Home
</title>

</head>

<body>

  <h1>
    Applications
  </h1>
  <br>
  <br>
  <br>
  <div>

    <table>
      <tr>
        <th>Project Title</th>
        <th>Status</th>
        <th>View Feedback</th>
        <th>Actions</th>
        <th>Date Submitted</th>
      </tr>
    </table>

</form>
</body>
</html>
