<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 4: Research Checklist (Part B)
  </h1>

  <div style="text-align:center;margin-top:30px;">
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>

    <span class="dash active finish"></span>
    <span class="step active"></span>
    <span class="dash active"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>
  </div>

<form action= "P7_Section4_PartC.php">
  <div class="container">

    <table>
      <tr>
        <th>Question</th>
        <th>B) Research that may need full review by the Sciences REAG</th>
        <th>YES</th>
        <th>NO</th>
      </tr>
      <tr>
        <td>1</td>
        <td>Does the research involve other vulnerable groups: eg, children; those with cognitive impairment?</td>
        <td><input type="radio"  name="q1" value="yes" required></td>
        <td><input type="radio"  name="q1" value="no" required></td>
      </tr>
      <tr>
          <td>2</td>
        <td>Is the research to be conducted in such a way that the relationship between participant and researcher is unequal (eg, a subject may feel under pressure to participate in order to avoid damaging a relationship with the researcher)?</td>
        <td><input type="checkbox" id="2" name="yes2" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="2" name="no2" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>3</td>
        <td>Does the project involve the collection of material that could be considered of a sensitive, personal, biographical, medical, psychological, social or physiological nature.</td>
        <td><input type="checkbox" id="3" name="yes3" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="3" name="no3" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>4</td>
        <td>Will the study require the cooperation of a gatekeeper for initial access to the groups or individuals to be recruited (eg, headmaster at a School; group leader of a self-help group)?</td>
        <td><input type="checkbox" id="4" name="yes4" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="4" name="no4" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>5</td>
        <td>Will it be necessary for participants to take part in the study without their knowledge and consent at the time? (eg, covert observation of people in non-public places?)</td>
        <td><input type="checkbox" id="5" name="yes5" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="5" name="no5" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>6</td>
        <td>Will the study involve discussion of sensitive topics (eg, sexual activity; drug use; criminal activity)?</td>
        <td><input type="checkbox" id="6" name="yes6" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="6" name="no6" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>7</td>
        <td>Are drugs, placebos or other substances (eg, food substances, vitamins) to be administered to the study participants or will the study involve invasive, intrusive or potentially harmful procedures of any kind?</td>
        <td><input type="checkbox" id="7" name="yes7" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="7" name="no7" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>9</td>
        <td>Is pain or more than mild discomfort likely to result from the study?</td>
        <td><input type="checkbox" id="8" name="yes8" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="8" name="no8" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>10</td>
        <td>Could the study induce psychological stress or anxiety or cause harm or negative consequences beyond the risks encountered in normal life?</td>
        <td><input type="checkbox" id="9" name="yes9" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="9" name="no9" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>11</td>
        <td>Will the study involve prolonged or repetitive testing?</td>
        <td><input type="checkbox" id="10" name="yes10" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="10" name="no10" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>12</td>
        <td>Will the research involve administrative or secure data that requires permission from the appropriate authorities before use?</td>
        <td><input type="checkbox" id="11" name="yes11" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="11" name="no11" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>13</td>
        <td>Is there a possibility that the safety of the researcher may be in question (eg, international research; locally employed research assistants)?</td>
        <td><input type="checkbox" id="12" name="yes12" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="12" name="no12" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>14</td>
        <td>Does the research involve participants carrying out any of the research activities themselves (i.e. acting as researchers as opposed to just being participants)?</td>
        <td><input type="checkbox" id="13" name="yes13" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="13" name="no13" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>15</td>
        <td>Will the research take place outside the UK? You may find the find the Proportionate Risk Assessment document useful.</td>
        <td><input type="checkbox" id="14" name="yes14" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="14" name="no14" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>16</td>
        <td>Will the outcome of the research allow respondents to be identified either directly or indirectly (eg, through aggregating separate data sources gathered from the internet)?</td>
        <td><input type="checkbox" id="15" name="yes15" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="15" name="no15" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>17</td>
        <td>Will research involve the sharing of data or confidential information beyond the initial consent given?</td>
        <td><input type="checkbox" id="16" name="yes16" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="16" name="no16" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>18</td>
        <td>Will financial inducements (other than reasonable expenses and compensation for time) be offered to participants?</td>
        <td><input type="checkbox" id="17" name="yes17" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="17" name="no17" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>19</td>
        <td>Are there any conflicts of interest with the proposed research/research findings? (eg, is the researcher working for the organisation under research or might the research or research findings cause a risk of harm to the participants(s) or the researcher(s) or the institution?)</td>
        <td><input type="checkbox" id="18" name="yes18" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="18" name="no19" value="no" onclick="currCheck(event)"required></td>
      </tr>
      <tr>
          <td>20</td>
        <td>Will the study involve the publication, sharing or potentially insecure electronic storage and/or transfer of data that might allow identification of individuals, either directly or indirectly? (e.g. publication of verbatim quotations from an online forum; sharing of audio/visual recordings; insecure transfer of personal data such as addresses, telephone numbers etc.; collecting identifiable personal data on unprotected** internet sites.)
[**Please note that Qualtrics and Sona Systems provide adequate data security and comply with the requirements of the EU-US Privacy Shield.]
</td>
        <td><input type="checkbox" id="19" name="yes19" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="19" name="no19" value="no" onclick="currCheck(event)"required></td>
      </tr>
    </table>

    <div class="pageButtons">
      <a onclick="saveData('P5_Section4_PartA.php')" class="button">Previous</a>
      <button type="submit" class="nextbtn1">Next</button>
    </div>
</div>
</form>
</body>
</html>

<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>
