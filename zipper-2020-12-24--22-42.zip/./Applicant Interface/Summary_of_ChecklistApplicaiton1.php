<?php
session_start();
$ApplicationID = $_SESSION["ApplicationID"];
?>

<?php
$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM Section2_Applicant_Details WHERE ApplicationID=" . $ApplicationID . " ORDER BY ApplicationID ASC LIMIT 1, 18446744073709551615";

$sql2 = "SELECT * FROM Section3_Declaration WHERE ApplicationID=" . $ApplicationID . " ORDER BY ApplicationID ASC";

if (mysqli_query($conn, $sql)) {
  $result = mysqli_query($conn, $sql);

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

if (mysqli_query($conn, $sql2)) {
  $result2 = mysqli_query($conn, $sql2);

} else {
  echo "Error: " . $sql2 . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Application Summary
</title>

</head>
<body>
    
  <h1>
    Application Summary
  </h1>
  
    <table id="FirstApplication" class="summary">
        <tr>
            <th colspan="3">&nbsp; ETHICS REVIEW CHECKLIST FOR RESEARCH WITH HUMAN PARTICIPANTS</th>
        </tr>
        <tr>
            <th>Section 1: Project Details</th>
            <th>Details</th>
            <th style="width:15%"><form action="P2_Section1ProjectDetails.php">
            <button type="submit" class="nextbtn1">Edit Section 1</button>
            </form></th>
        </tr>
        <tr>
            <td>Project title</td>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td>Planned start date</td>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td>Planned end date</td>
            <<td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td>Funder</td>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <th>Section 2: Applicant Details</th>
            <th>Details</th>
            <th style="width:15%"><form action="P3_Section2ApplicantDetails.php">
            <button type="submit" class="nextbtn1">Edit Section 2</button>
            </form></th>
        </tr>
    <tr>
      <td>Applicant name</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>School/Department</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Email</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Telephone</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Postcode</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Address</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Level Of Study/Staff</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    </table>
    
    <table class="applicants">
        <th colspan="8">&nbsp; Other Applicants</th>
  <tr>
    <th>Name</th>
    <th>Department</th>
    <th>Email</th>
    <th>Telephone</th>
    <th>Postcode</th>
    <th>Address</th>
    <th>Study</th>
    <th>Delete</th>
  </tr>
      
<?php 
 
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>". $row["ApplicantName"]."</td>";
        echo "<td>". $row["Department"]."</td>";
        echo "<td>". $row["Email"]."</td>";
        echo "<td>". $row["Telephone"]."</td>";
        echo "<td>". $row["Postcode"]."</td>";
        echo "<td>". $row["Address"]."</td>";
        echo "<td>". $row["Study"]."</td>";
        
        $nextPage = urlencode("Applicant Interface/Summary_With_FullApplication.php");
        
        
        echo "<td><a href='../PHP/DeleteApplicant.php?id=".$row["ApplicantID"]."&next=$nextPage'> <img alt='https://www.flaticon.com/free-icon/delete_1345874?term=delete&page=1&position=3&related_item_id=1345874' src='https://www.flaticon.com/svg/static/icons/svg/1345/1345874.svg' width='20' height='20'></a></td>";
    }
?>
</table>

<table id="FirstApplication" class="summary">
        <tr>
            <th>Section 3: Declaration & Signatures</th>
            <th>Details</th>
            <th style="width:15%"><form action="P4_Section3Declaration&Signatures.php">
            <button type="submit" class="nextbtn1">Edit Section 3</button>
            </form></th>
        </tr>
    <tr>
      <td>Agreed with the terms and conditions</td>
      <td colspan="2">&nbsp;</td>
    </tr>
        </table>
    
    <table class="applicants">
    <tr>
    <th colspan="3">&nbsp; Supervisor(s) Details</th>
    </tr>
    <tr>
    <th>Supervisor(s) Name</th>
    <th>Supervisor(s) Email</th>
    <th>Delete</th>
  </tr>
      
<?php 
 
    while($row = mysqli_fetch_assoc($result2)) {
        echo "<tr>";
        echo "<td>". $row["SupervisorName"]."</td>";
        echo "<td>". $row["SupervisorEmail"]."</td>";
        
        $nextPage = urlencode("Applicant Interface/Summary_With_FullApplication.php");
        
        
        echo "<td><a href='../PHP/DeleteSupervisor.php?id=".$row["SupervisorID"]."&next=$nextPage'> <img alt='https://www.flaticon.com/free-icon/delete_1345874?term=delete&page=1&position=3&related_item_id=1345874' src='https://www.flaticon.com/svg/static/icons/svg/1345/1345874.svg' width='20' height='20'></a></td>";
    }
?>
</table>
    
    <table id="FirstApplication" class="summary">
    <tr>
      <th>Section 4: Research Checklist (Part A)</th>
      <th>Research that may need to be reviewed by an NHS Research Ethics Committee, the Social Care Research Ethics Committee (SCREC) or other external ethics committee (if yes, please give brief details as an annex)</th>
      <th style="width:15%"><form action="P5_Section4_PartA.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Will the study involve recruitment of patients through the NHS or the use of NHS patient data or samples?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve the collection of tissue samples (including blood, saliva, urine, etc.) or other biological samples from participants, or the use of existing samples?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve participants, or their data, from adult social care, including home care, or residents from a residential or nursing care home?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve research participants identified because of their status as relatives or carers of past or present users of these services?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Does the study involve participants aged 16 or over who are unable to give informed consent (e.g. people with learning disabilities or dementia)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a social care study funded by the Department of Health?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a health-related study involving prisoners?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a clinical investigation of a non-CE Marked medical device, or a medical device which has been modified or is being used outside its CE Mark intended purpose, conducted by or with the support of the manufacturer or another commercial company to provide data for CE marking purposes? (a CE mark signifies compliance with European safety standards)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a clinical trial of an investigational medicinal product or a medical device?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <th>Section 4: Research Checklist (Part B)</th>
      <th>Research that may need full review by the Sciences REAG</th>
      <th style="width:15%"><form action="P6_Section4_PartB.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Does the research involve other vulnerable groups: eg, children; those with cognitive impairment?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research to be conducted in such a way that the relationship between participant and researcher is unequal (eg, a subject may feel under pressure to participate in order to avoid damaging a relationship with the researcher)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Does the project involve the collection of material that could be considered of a sensitive, personal, biographical, medical, psychological, social or physiological nature.</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study require the cooperation of a gatekeeper for initial access to the groups or individuals to be recruited (eg, headmaster at a School; group leader of a self-help group)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will it be necessary for participants to take part in the study without their knowledge and consent at the time? (eg, covert observation of people in non-public places?)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve discussion of sensitive topics (eg, sexual activity; drug use; criminal activity)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Are drugs, placebos or other substances (eg, food substances, vitamins) to be administered to the study participants or will the study involve invasive, intrusive or potentially harmful procedures of any kind?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is pain or more than mild discomfort likely to result from the study?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Could the study induce psychological stress or anxiety or cause harm or negative consequences beyond the risks encountered in normal life?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve prolonged or repetitive testing?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the research involve administrative or secure data that requires permission from the appropriate authorities before use?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is there a possibility that the safety of the researcher may be in question (eg, international research; locally employed research assistants)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Does the research involve participants carrying out any of the research activities themselves (i.e. acting as researchers as opposed to just being participants)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the research take place outside the UK? You may find the find the Proportionate Risk Assessment document useful.</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the outcome of the research allow respondents to be identified either directly or indirectly (eg, through aggregating separate data sources gathered from the internet)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will research involve the sharing of data or confidential information beyond the initial consent given?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will financial inducements (other than reasonable expenses and compensation for time) be offered to participants?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Are there any conflicts of interest with the proposed research/research findings? (eg, is the researcher working for the organisation under research or might the research or research findings cause a risk of harm to the participants(s) or the researcher(s) or the institution?)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve the publication, sharing or potentially insecure electronic storage and/or transfer of data that might allow identification of individuals, either directly or indirectly? (e.g. publication of verbatim quotations from an online forum; sharing of audio/visual recordings; insecure transfer of personal data such as addresses, telephone numbers etc.; collecting identifiable personal data on unprotected** internet sites.)
      [**Please note that Qualtrics and Sona Systems provide adequate data security and comply with the requirements of the EU-US Privacy Shield.]
      </td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <th>Section 4: Research Checklist (Part C)</th>
      <th>Security Sensitive Material</th>
         <th style="width:15%"><form action="P7_Section4_PartC.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Does your research involve access to or use of material covered by the Terrorism Act?(The Terrorism Act (2006) outlaws the dissemination of records, statements and other documents that can be interpreted as promoting and endorsing terrorist acts. By answering ‘yes’ you are registering your legitimate use of this material with the Research Ethics Advisory Group. In the event of a police investigation, this registration will help you to demonstrate that your use of this material is legitimate and lawful).</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <th>Section 4: Research Checklist (Part D)</th>
      <th>Prevent Agenda</th>
       <th style="width:15%"><form action="P8_Section4_PartD.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Does the research have the potential to radicalise people who are vulnerable to supporting terrorism or becoming terrorists themselves?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="3">&nbsp;<textarea placeholder="Write your feedback";></textarea></td>
    </tr>
  </table>
  <br>
  <div class="pageButtons">
      <button type="submit" class="nextbtn1">Delete Application</button>
      <button type="submit" class="nextbtn1">Save Application</button>
      <button type="submit" class="nextbtn1">Submit Applciation</button>
    </div>
</body>
</html>