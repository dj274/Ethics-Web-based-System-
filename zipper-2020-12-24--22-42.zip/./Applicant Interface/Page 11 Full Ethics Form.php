<?php

session_start();
$ApplicationID = $_SESSION["ApplicationID"];
require('../db.php');
if(isset($_POST['q1'])){
$q1 = $_POST['q1'];
$q2 = $_POST['q2'];
$q3 = $_POST['q3'];
$q4 = $_POST['q4'];
$q5 = $_POST['q5'];
$q6 = $_POST['q6'];
$q7 = $_POST['q7'];
$q8 = $_POST['q8'];
$q9 = $_POST['q9'];

$ApplicationID = $_SESSION["ApplicationID"];

$sql = "INSERT INTO Full_Section2_Risk_and_ethical_issues (Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9 ApplicationID)
VALUES ('$q1', '$q2', '$q3', '$q4', '$q5', '$q6', '$q7', '$q8', '$q9', $ApplicationID)";
$result = mysqli_query($conn,$sql);
  if($result){
     header("Location:P12_Section3Recruitment&InformedConsent.php");
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 2: Risks and ethical issues
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active"></span>
      <span class="dash active"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
    </div>

<form action= "P12_Section3Recruitment&InformedConsent.php">
  <div class="container">
    <label for="apn"><b>Please list the principal inclusion and exclusion criteria</b></label>
    <textarea rows="10" cols="30" wrap="physical name="q1"></textarea>

    <br>

    <label for="apn"><b>How long will each research participant be in the study in total, from when they give informed consent until their last contact with the research team?</b></label>
    <textarea rows="10" cols="30" wrap="physical"name="q2"></textarea>

    <br>

    <label for="apn"><b>What are the potential risks and burdens for research participants and how will you minimise them?  (Describe any risks and burdens that could occur as a result of participation in the research, such as pain, discomfort, distress, intrusion, inconvenience or changes to lifestyle.  Describe what steps would be taken to minimise risks and burdens as far as possible)</b></label>
    <textarea rows="10" cols="30" wrap="physical"name="q3"></textarea>

    <br>

    <label for="apn"><b>Please describe what measures you have in place in the event of any unexpected outcomes or adverse effects to participants arising from involvement in the project</b></label>
    <textarea rows="10" cols="30" wrap="physical"name="q4"></textarea>

    <br>

    <label for="apn"><b>Will interviews/questionnaires or group discussions include topics that might be sensitive, embarrassing or upsetting, or is it possible that criminal or other disclosures requiring action could occur during the study?</b></label>
    <br><input type="radio" id="yes1" name="answer1" onclick="manageTextArea(true, 'answerarea1');" value="Yes">
        <label for="yes1">Yes, please describe the procedures in place to deal with these issues</label><br>
        <input type="radio" id="no1" name="answer1" onclick="manageTextArea(false, 'answerarea1');" value="No">
        <label for="no1">No</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea1"name="q5"></textarea>

    <br>

    <label for="apn"><b>What is the potential benefit to research participants?</b></label>
    <textarea rows="10" cols="30" wrap="physical"name="q6"></textarea>

    <br>

    <label for="apn"><b>What are the potential risks to the researchers themselves?</b></label>
    <textarea rows="10" cols="30" wrap="physical"name="q7"></textarea>

    <br>

    <label for="apn"><b>Will there be any risks to the University?  (Consider issues such as reputational risk; research that may give rise to contentious or controversial findings; could the funder be considered controversial or have the potential to cause reputational risk to the University?)</b></label>
    <br><input type="radio" id="yes2" name="q8" value="Yes">
        <label for="yes2">Yes</label><br>
        <input type="radio" id="no2" name="q8" value="No">
        <label for="no2">No</label><br>

    <br>

    <label for="apn"><b>Will any intervention or procedure, which would normally be considered a part of routine care, be withheld from the research participants? For example, the disturbance of a school child’s day or access to their normal educational entitlement and curriculum).</b></label>
    <br><input type="radio" id="yes3" name="q9" onclick="manageTextArea(true, 'answerarea3');" value="Yes">
        <label for="yes3">Yes, give details and justification</label><br>
        <input type="radio" id="no3" name="q9" onclick="manageTextArea(false, 'answerarea3');" value="No">
        <label for="no3">No</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="q9"></textarea>

    <br>


  <div class="pageButtons">
    <a href="P10_Section1Overview.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Next</button>
  </div>
</div>

</form>
</body>
</html>


