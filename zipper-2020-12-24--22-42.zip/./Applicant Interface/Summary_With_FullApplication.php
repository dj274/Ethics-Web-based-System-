<?php
session_start();
$ApplicationID = $_SESSION["ApplicationID"];
?>

<?php
$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM Section2_Applicant_Details WHERE ApplicationID=" . $ApplicationID . " ORDER BY ApplicationID ASC LIMIT 1, 18446744073709551615";

$sql2 = "SELECT * FROM Section3_Declaration WHERE ApplicationID=" . $ApplicationID . " ORDER BY ApplicationID ASC";

if (mysqli_query($conn, $sql)) {
  $result = mysqli_query($conn, $sql);

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

if (mysqli_query($conn, $sql2)) {
  $result2 = mysqli_query($conn, $sql2);

} else {
  echo "Error: " . $sql2 . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Application Summary
</title>

</head>
<body>
    
  <h1>
    Application Summary
  </h1>
  
    <table id="FirstApplication" class="summary">
        <tr>
            <th colspan="3">&nbsp; ETHICS REVIEW CHECKLIST FOR RESEARCH WITH HUMAN PARTICIPANTS</th>
        </tr>
        <tr>
            <th>Section 1: Project Details</th>
            <th>Details</th>
            <th style="width:15%"><form action="P2_Section1ProjectDetails.php">
            <button type="submit" class="nextbtn1">Edit Section 1</button>
            </form></th>
        </tr>
        <tr>
            <td>Project title</td>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td>Planned start date</td>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td>Planned end date</td>
            <<td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td>Funder</td>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <th>Section 2: Applicant Details</th>
            <th>Details</th>
            <th style="width:15%"><form action="P3_Section2ApplicantDetails.php">
            <button type="submit" class="nextbtn1">Edit Section 2</button>
            </form></th>
        </tr>
    <tr>
      <td>Applicant name</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>School/Department</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Email</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Telephone</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Postcode</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Address</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Level Of Study/Staff</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    </table>
    
    <table class="applicants">
        <th colspan="8">&nbsp; Other Applicants</th>
  <tr>
    <th>Name</th>
    <th>Department</th>
    <th>Email</th>
    <th>Telephone</th>
    <th>Postcode</th>
    <th>Address</th>
    <th>Study</th>
    <th>Delete</th>
  </tr>
      
<?php 
 
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>". $row["ApplicantName"]."</td>";
        echo "<td>". $row["Department"]."</td>";
        echo "<td>". $row["Email"]."</td>";
        echo "<td>". $row["Telephone"]."</td>";
        echo "<td>". $row["Postcode"]."</td>";
        echo "<td>". $row["Address"]."</td>";
        echo "<td>". $row["Study"]."</td>";
        
        $nextPage = urlencode("Applicant Interface/Summary_With_FullApplication.php");
        
        
        echo "<td><a href='../PHP/DeleteApplicant.php?id=".$row["ApplicantID"]."&next=$nextPage'> <img alt='https://www.flaticon.com/free-icon/delete_1345874?term=delete&page=1&position=3&related_item_id=1345874' src='https://www.flaticon.com/svg/static/icons/svg/1345/1345874.svg' width='20' height='20'></a></td>";
    }
?>
</table>

<table id="FirstApplication" class="summary">
        <tr>
            <th>Section 3: Declaration & Signatures</th>
            <th>Details</th>
            <th style="width:15%"><form action="P4_Section3Declaration&Signatures.php">
            <button type="submit" class="nextbtn1">Edit Section 3</button>
            </form></th>
        </tr>
    <tr>
      <td>Agreed with the terms and conditions</td>
      <td colspan="2">&nbsp;</td>
    </tr>
        </table>
    
    <table class="applicants">
    <tr>
    <th colspan="3">&nbsp; Supervisor(s) Details</th>
    </tr>
    <tr>
    <th>Supervisor(s) Name</th>
    <th>Supervisor(s) Email</th>
    <th>Delete</th>
  </tr>
      
<?php 
 
    while($row = mysqli_fetch_assoc($result2)) {
        echo "<tr>";
        echo "<td>". $row["SupervisorName"]."</td>";
        echo "<td>". $row["SupervisorEmail"]."</td>";
        
        $nextPage = urlencode("Applicant Interface/Summary_With_FullApplication.php");
        
        
        echo "<td><a href='../PHP/DeleteSupervisor.php?id=".$row["SupervisorID"]."&next=$nextPage'> <img alt='https://www.flaticon.com/free-icon/delete_1345874?term=delete&page=1&position=3&related_item_id=1345874' src='https://www.flaticon.com/svg/static/icons/svg/1345/1345874.svg' width='20' height='20'></a></td>";
    }
?>
</table>
    
    <table id="FirstApplication" class="summary">
    <tr>
      <th>Section 4: Research Checklist (Part A)</th>
      <th>Research that may need to be reviewed by an NHS Research Ethics Committee, the Social Care Research Ethics Committee (SCREC) or other external ethics committee (if yes, please give brief details as an annex)</th>
      <th style="width:15%"><form action="P5_Section4_PartA.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Will the study involve recruitment of patients through the NHS or the use of NHS patient data or samples?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve the collection of tissue samples (including blood, saliva, urine, etc.) or other biological samples from participants, or the use of existing samples?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve participants, or their data, from adult social care, including home care, or residents from a residential or nursing care home?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve research participants identified because of their status as relatives or carers of past or present users of these services?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Does the study involve participants aged 16 or over who are unable to give informed consent (e.g. people with learning disabilities or dementia)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a social care study funded by the Department of Health?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a health-related study involving prisoners?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a clinical investigation of a non-CE Marked medical device, or a medical device which has been modified or is being used outside its CE Mark intended purpose, conducted by or with the support of the manufacturer or another commercial company to provide data for CE marking purposes? (a CE mark signifies compliance with European safety standards)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research a clinical trial of an investigational medicinal product or a medical device?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <th>Section 4: Research Checklist (Part B)</th>
      <th>Research that may need full review by the Sciences REAG</th>
      <th style="width:15%"><form action="P6_Section4_PartB.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Does the research involve other vulnerable groups: eg, children; those with cognitive impairment?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is the research to be conducted in such a way that the relationship between participant and researcher is unequal (eg, a subject may feel under pressure to participate in order to avoid damaging a relationship with the researcher)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Does the project involve the collection of material that could be considered of a sensitive, personal, biographical, medical, psychological, social or physiological nature.</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study require the cooperation of a gatekeeper for initial access to the groups or individuals to be recruited (eg, headmaster at a School; group leader of a self-help group)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will it be necessary for participants to take part in the study without their knowledge and consent at the time? (eg, covert observation of people in non-public places?)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve discussion of sensitive topics (eg, sexual activity; drug use; criminal activity)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Are drugs, placebos or other substances (eg, food substances, vitamins) to be administered to the study participants or will the study involve invasive, intrusive or potentially harmful procedures of any kind?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is pain or more than mild discomfort likely to result from the study?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Could the study induce psychological stress or anxiety or cause harm or negative consequences beyond the risks encountered in normal life?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve prolonged or repetitive testing?</td>
      <td colspan="2">&nbsp;</td>>
    </tr>
    <tr>
      <td>Will the research involve administrative or secure data that requires permission from the appropriate authorities before use?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Is there a possibility that the safety of the researcher may be in question (eg, international research; locally employed research assistants)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Does the research involve participants carrying out any of the research activities themselves (i.e. acting as researchers as opposed to just being participants)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the research take place outside the UK? You may find the find the Proportionate Risk Assessment document useful.</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the outcome of the research allow respondents to be identified either directly or indirectly (eg, through aggregating separate data sources gathered from the internet)?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will research involve the sharing of data or confidential information beyond the initial consent given?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will financial inducements (other than reasonable expenses and compensation for time) be offered to participants?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Are there any conflicts of interest with the proposed research/research findings? (eg, is the researcher working for the organisation under research or might the research or research findings cause a risk of harm to the participants(s) or the researcher(s) or the institution?)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will the study involve the publication, sharing or potentially insecure electronic storage and/or transfer of data that might allow identification of individuals, either directly or indirectly? (e.g. publication of verbatim quotations from an online forum; sharing of audio/visual recordings; insecure transfer of personal data such as addresses, telephone numbers etc.; collecting identifiable personal data on unprotected** internet sites.)
      [**Please note that Qualtrics and Sona Systems provide adequate data security and comply with the requirements of the EU-US Privacy Shield.]
      </td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <th>Section 4: Research Checklist (Part C)</th>
      <th>Security Sensitive Material</th>
         <th style="width:15%"><form action="P7_Section4_PartC.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Does your research involve access to or use of material covered by the Terrorism Act?(The Terrorism Act (2006) outlaws the dissemination of records, statements and other documents that can be interpreted as promoting and endorsing terrorist acts. By answering ‘yes’ you are registering your legitimate use of this material with the Research Ethics Advisory Group. In the event of a police investigation, this registration will help you to demonstrate that your use of this material is legitimate and lawful).</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <th>Section 4: Research Checklist (Part D)</th>
      <th>Prevent Agenda</th>
       <th style="width:15%"><form action="P8_Section4_PartD.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td>Does the research have the potential to radicalise people who are vulnerable to supporting terrorism or becoming terrorists themselves?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
  </table>
  
  <br>
  <br>
  <br>
  <br>
  
  <table id="SecondApplication" class="summary">
      <tr>
          <th colspan="3">&nbsp;
              FULL ETHICS APPLICATION FOR RESEARCH WITH HUMAN PARTICIPANTS
         </th>
     </tr>
     <tr>
      <th>Section 1: Overview</th>
      <th>Details</th>
      <th style="width:15%"><form action="P10_Section1Overview.php">
            <button type="submit" class="nextbtn1">Edit Section 1</button>
            </form></th>
    </tr>
    <tr>
      <td>Does the research have the potential to radicalise people who are vulnerable to supporting terrorism or becoming terrorists themselves?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    
     <tr>
      <th>Section 2: Risks & Ethical Issues</th>
      <th>Details</th>
      <th style="width:15%"><form action="P11_Section2Risk&EthicalIssues.php">
            <button type="submit" class="nextbtn1">Edit Section 2</button>
            </form></th>
    </tr>
     <tr>
      <td>Please list the principal inclusion and exclusion criteria</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>How long will each research participant be in the study in total, from when they give informed consent until their last contact with the research team?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>What are the potential risks and burdens for research participants and how will you minimise them?  (Describe any risks and burdens that could occur as a result of participation in the research, such as pain, discomfort, distress, intrusion, inconvenience or changes to lifestyle.  Describe what steps would be taken to minimise risks and burdens as far as possible)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>Please describe what measures you have in place in the event of any unexpected outcomes or adverse effects to participants arising from involvement in the project</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>Will interviews/questionnaires or group discussions include topics that might be sensitive, embarrassing or upsetting, or is it possible that criminal or other disclosures requiring action could occur during the study? If yes, please describe the procedures in place to deal with these issues</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>What is the potential benefit to research participants?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>What are the potential risks to the researchers themselves?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>Will there be any risks to the University?  (Consider issues such as reputational risk; research that may give rise to contentious or controversial findings; could the funder be considered controversial or have the potential to cause reputational risk to the University?)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>Will any intervention or procedure, which would normally be considered a part of routine care, be withheld from the research participants?  (If yes, give details and justification).  For example, the disturbance of a school child’s day or access to their normal educational entitlement and curriculum).</td>
      <td colspan="2">&nbsp;</td>
    </tr>

    <tr>
      <th>Section 3: Recruitment & Informed Consent</th>
      <th>Details</th>
      <th style="width:15%"><form action="P12_Section3Recruitment&InformedConsent.php">
            <button type="submit" class="nextbtn1">Edit Section 3</button>
            </form></th>
    </tr>
    <tr>
      <td>How and by whom will potential participants, records or samples be identified?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
     <tr>
      <td>Will this involve reviewing or screening identifiable personal information of potential participants or any other person?  (If ‘yes’, give details)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Has prior consent been obtained or will it be obtained for access to identifiable personal information?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will you obtain informed consent from or on behalf of research participants?  (If ‘yes’ please give details.  If you are not planning to gain consent, please explain why not).</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will you record informed consent in writing?  (If ‘no’, how will it be recorded?)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>How long will you allow potential participants to decide whether or not to take part?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>What arrangements have been made for persons who might not adequately understand verbal explanations or written information given in English, or have special communication needs?  (eg,  translation, use of interpreters?)</td>
     <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>If no arrangements will be made, explain the reasons (eg, resource constraints)</td>
      <td colspan="2">&nbsp;</td>
    </tr>

    <tr>
      <th>Section 4: Confidentiality</th>
      <th>Details</th>
      <th style="width:15%"><form action="P13_Section4Confidentiality.php">
            <button type="submit" class="nextbtn1">Edit Section 4</button>
            </form></th>
    </tr>
    <tr>
      <td> In this section personal data means any data relating to a participant who could potentially be identified.  It includes pseudonymised data capable of being linked to a participant through a unique code number.
      If you will be undertaking any of the following activities at any stage (including in the identification of potential participants) please give details and explain the safeguarding measures you will employ
      <ul>
        <li>Electronic transfer by magnetic or optical media, email or computer networks</li>
        <li>Sharing of personal data outside the European Economic Area</li>
        <li>Use of personal addresses, postcodes, faxes, emails or telephone numbers</li>
        <li>Publication of direct quotations from respondents</li>
        <li>Publication of data that might allow identification of individuals, either directly or indirectly</li>
        <li>Use of audio/visual recording devices</li>
        <li>Storage of personal data on any of the following:</li>
      <d1>
        <dd> - Manual files</dd>
        <dd> - University computers</dd>
        <dd> - Home or other personal computers</dd>
        <dd> - Private company computers</dd>
        <dd> - Laptop computers</dd>
      </d1></td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
    <tr>
      <td>How will you ensure the confidentiality of personal data?  (eg, anonymisation or pseudonymisation of data)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Who will have access to participants’ personal data during the study?</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>How long will personal data be stored or accessed after the study has ended?  (If longer than 12 months, please justify)</td>
     <td colspan="2">&nbsp;</td>
    </tr>

    <tr>
      <th>Section 5: Incentives & Payments</th>
      <th>Details</th>
            <th style="width:15%"><form action="P14_Section5Incentives&Payments.php">
            <button type="submit" class="nextbtn1">Edit Section 5</button>
            </form></th>
    </tr>
      <tr>
      <td>Will research participants receive any payments, reimbursement of expenses or any other benefits or incentives for taking part in this research?  (If ‘yes’, please give details)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will individual researchers receive any personal payment over and above normal salary, or any other benefits or incentives, for taking part in this research?  (If ‘yes’, please give detai)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Does the Chief Investigator or any other investigator/collaborator have any direct personal involvement (e.g. financial, share holding, personal relationship, etc) in the organisations sponsoring or funding the research that may give rise to a possible conflict of interest?  (If ‘yes’, please give details) </td>
      <td colspan="2">&nbsp;</td>
    </tr>

    <tr>
      <th>Section 6: Publication & Dissemination</th>
      <th>Details</th>
      <th style="width:15%"><form action="P15_Section6Publication&Dissemination.php">
            <button type="submit" class="nextbtn1">Edit Section 6</button>
            </form></th>
    </tr>
    <tr>
      <td>How do you intend to report and disseminate the results of the study?  If you do not plan to report or disseminate the results please give your justification</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Will you inform participants of the results?  (Please give details of how you will inform participants or justify if not doing so)</td>
      <td colspan="2">&nbsp;</td>
    </tr>

    <tr>
      <th>Section 7: Management of the research</th>
      <th>Details</th>
       <th style="width:15%"><form action="P16_Section7ManagementOfTheResearch.php">
            <button type="submit" class="nextbtn1">Edit Section 7</button>
            </form></th>
    </tr>
    <tr>
      <td>Other key investigators/collaborators.  (Please include all grant co-applicants, protocol authors and other key members of the Chief Investigator’s team, including non-doctoral student researchers)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Has this or a similar application been previously rejected by a research Ethics Committee in the UK or another country?  (If yes, please give details of rejected application and explain in the summary of main issues how the reasons for the unfavourable opinion have been addressed in this application)</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td>Where will the research take place?</td>
      <td colspan="2">&nbsp;</td>
    </tr>

     <tr>
      <th>Section 8: Insurance/Indemnity</th>
      <th>Details</th>
      <th style="width:15%"><form action="P17_Section8InsuranceIndemnity.php">
            <button type="submit" class="nextbtn1">Edit Section 8</button>
            </form></th>
    </tr>
      <tr>
      <td>Does UoK’s insurer need to be notified about your project before insurance cover can be provided?
      The majority of research carried out at UoK is covered automatically by existing policies, however, if your project entails more than usual risk or involves an overseas country in the developing world or where there is or has recently been conflict, please check with the Insurance Office that cover can be provided.</td> 
      <td colspan="2">&nbsp;</td>
      </tr>

      <tr>
      <th>Section 9: Children</th>
      <th>Details</th>
         <th style="width:15%"><form action="P18_Section9Children.php">
            <button type="submit" class="nextbtn1">Edit Section 9</button>
            </form></th>
    </tr>
    <tr>
      <td>Do you plan to include any participants who are children under 16?  (If no, go to next section)</td>
     <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
      <td>Please specify the potential age range of children under 16 who will be included and give reasons for carrying out the research with this age group</td>
      <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
      <td>Please describe the arrangements for seeking informed consent from a person with parental responsibility and/or from children able to give consent for themselves</td>
      <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
      <td>If you intend to provide children under 16 with information about the research and seek their consent or agreement, please outline how this process will vary according to their age and level of understanding</td>
     <td colspan="2">&nbsp;</td>
      </tr>

      <tr>
      <th>Section 10: Participants unable to consent for themselves</th>
      <th>Details</th>
        <th style="width:15%"><form action="P19_Section10ParticipantsUnableToConsentForThemselves.php">
            <button type="submit" class="nextbtn1">Edit Section 10</button>
            </form></th>
    </tr>
    <tr>
      <td>Do you plan to include any participants who are adults unable to consent for themselves through physical or mental incapacity?  (If yes, the research must be reviewed by an NHS REC or SCREC)</td>
      <td colspan="2">&nbsp;</td>
      </tr> 
      <tr>
      <td>Is the research related to the ‘impairing condition’ that causes the lack of capacity, or to the treatment of those with that condition?</td>
      <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
      <td>Could the research be undertaken as effectively with people who do have the capacity to consent to participate?</td>
      <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
      <td>Is it possible that the capacity of participants could fluctuate during the research?  (If yes, the research must be reviewed by an NHS REC or SCREC)</td>
      <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
      <td>Who inside or outside the research team will decide whether or not the participants have the capacity to give consent?  What training/experience will they have to enable them to reach this decision?</td>
      <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
      <td>What will be the criteria for withdrawal of participants?</td>
      <td colspan="2">&nbsp;</td>
      </tr>

       <tr>
      <th>Section 11: Declaration</th>
      <th>Details</th>
      <th style="width:15%"><form action="P20_Section11Declaration.php">
            <button type="submit" class="nextbtn1">Edit Section 11</button>
            </form></th>
    </tr>
    <tr>
      <td>Agreed with the terms and conditions</td>
      <td colspan="2">&nbsp;</td>
    </tr>
  </table>
  <br>
  <div class="pageButtons">
      <button type="submit" class="nextbtn1">Delete Application</button>
      <button type="submit" class="nextbtn1">Save Application</button>
      <button type="submit" class="nextbtn1">Submit Applciation</button>
    </div>
</body>
</html>