<!DOCTYPE html>
<html>

<head>
<style>
h1 {
  color: black;
  font-family: sans-serif;
  font-size: 200%;
  position: static;
  text-align: center;
  text-decoration: underline;
}

p {
  color: black;
  font-family: PT Sans ;
  font-size: 150%;
  position:static;
  background-color: white;
  border: 5px solid #d8d8d8;
  padding: 30px;
  margin: 50px;
}


#button{
  font-family: sans-serif;
  font-weight: normal;
  font-size: 20px;
  background-color: #f1f1f1;
  color: black;
  padding: 50px 50px 50px 50px;
  margin: 5px;
  text-decoration: none;
}

#button:hover, button:hover {
  background-color: #d8d8d8;
  cursor:pointer;
}

.center {
  margin: 10;
  position: absolute;
  top: 85%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}

</style>

<title>
Form
</title>

</head>

<body>
  <h1>
    ETHICS REVIEW CHECKLIST FOR RESEARCH WITH HUMAN PARTICIPANTS – FACULTY OF SCIENCES
  </h1>

  <p>
    A checklist should be completed for every research project in order to identify whether a full application for ethics approval needs to be submitted. The principal investigator or, where the principal investigator is a student, the supervisor, is responsible for exercising appropriate professional judgement in this review.
  </p>

  <p>
    This checklist must be completed before potential participants are approached to take part in any research. All forms must be signed by the School’s Research Ethics Advisory Group representative.
  </p>

<a class="center" href="P2_Section1ProjectDetails.php" id="button">Start Application</a>

</body>
</html>
