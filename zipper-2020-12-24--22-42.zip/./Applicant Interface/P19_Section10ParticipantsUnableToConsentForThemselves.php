<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 10: Participants unable to consent for themselves
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active" ></span>
      <span class="dash active"></span>
      <span class="step" ></span>
    </div>

<form action= "P20_Section11Declaration.php">
  <div class="container">

    <label for="apn"><b>Do you plan to include any participants who are adults unable to consent for themselves through physical or mental incapacity?</b></label>
    <br><input type="radio" id="yes1" name="answer1" value="Yes">
        <label for="yes1">Yes, the research must be reviewed by an NHS REC or SCREC</label><br>
        <input type="radio" id="no1" name="answer1" value="No">
        <label for="no1">No</label><br>

        <br>

   <label for="apn"><b>Is the research related to the ‘impairing condition’ that causes the lack of capacity, or to the treatment of those with that condition?</b></label>
   <br><input type="radio" id="yes2" name="answe2" value="Yes">
        <label for="yes2">Yes, proceed to next question </label><br>
        <input type="radio" id="no2" name="answer2" value="No">
        <label for="no2">No, the study should proceed without involving those who do not have the capacity to consent to participation </label><br>

        <br>

    <label for="apn"><b>Could the research be undertaken as effectively with people who do have the capacity to consent to participate?</b></label>
    <br><input type="radio" id="yes1" name="answer1" value="Yes">
        <label for="yes1">Yes, then the study should exclude those without the capacity to consent to participation</label><br>
        <input type="radio" id="no1" name="answer1" value="No">
        <label for="no1">No, then the inclusion of people without capacity in the study can be justified</label><br>

        <br>

    <label for="apn"><b>Is it possible that the capacity of participants could fluctuate during the research?</b></label>
    <br><input type="radio" id="yes2" name="answer2" value="Yes">
        <label for="yes2">Yes, the research must be reviewed by an NHS REC or SCREC</label><br>
        <input type="radio" id="no2" name="answer2" value="No">
        <label for="no2">No</label><br>

        <br>

    <label for="apn"><b>Who inside or outside the research team will decide whether or not the participants have the capacity to give consent?  What training/experience will they have to enable them to reach this decision?</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>What will be the criteria for withdrawal of participants?</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

  <div class="pageButtons">
    <a href="P18_Section9Children.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Next</button>
  </div>
</div>

</form>
</body>
</html>

<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>

