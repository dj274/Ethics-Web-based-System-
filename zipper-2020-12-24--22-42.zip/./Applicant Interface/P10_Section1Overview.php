<?php

session_start();
$ApplicationID = $_SESSION["ApplicationID"];
require('../db.php');
if(isset($_POST['q1'])){
$q1 = $_POST['q1'];
$ApplicationID = $_SESSION["ApplicationID"];

$sql = "INSERT INTO Full_Section1_Overview (Q1,ApplicationID)
VALUES ('$q1',$ApplicationID)";
$result = mysqli_query($conn,$sql);
  if($result){
     header("Location:Page 11 Full Ethics Form.php");
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 1: Overview
  </h1>


  <div style="text-align:center;margin-top:30px;">
    <span class="step active"></span>
    <span class="dash active"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
    <span class="dash"></span>
    <span class="step" ></span>
  </div>

<form action= "" method="post">
  <div class="container">
    <label for="p"><b>Lay Summary (Please provide a brief summary of the study)</b</label>
      <br>
    <textarea rows="10" cols="30" wrap="physical"name="q1"></textarea required>

    <div class="pageButtons">
      <button type="submit" class="nextbtn1">Next</button>
    </div>
</div>
</form>
</body>
</html>

