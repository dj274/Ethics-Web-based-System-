<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 7: Management of the research
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active"></span>
      <span class="dash active"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
    </div>

<form action= "P17_Section8InsuranceIndemnity.php">
  <div class="container">
    <label for="apn"><b>Other key investigators/collaborators.  (Please include all grant co-applicants, protocol authors and other key members of the Chief Investigator’s team, including non-doctoral student researchers)</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>Has this or a similar application been previously rejected by a research Ethics Committee in the UK or another country?  </b></label>
    <br><input type="radio" id="yes1" name="answer1" onclick="manageTextArea(true, 'answerarea1');" value="Yes">
        <label for="yes1">Yes, please give details of rejected application and explain in the summary of main issues how the reasons for the unfavourable opinion have been addressed in this application</label><br>
        <input type="radio" id="no1" name="answer1" onclick="manageTextArea(false, 'answerarea1');" value="No">
        <label for="no1">No</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea1"></textarea>

    <br>

    <label for="apn"><b>Where will the research take place?</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

  <div class="pageButtons">
    <a href="P15_Section6Publication&Dissemination.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Next</button>
  </div>
</div>

</form>
</body>
</html>

<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>

