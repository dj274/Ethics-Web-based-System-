<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 5: Incentives and payments
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active"></span>
      <span class="dash active"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
    </div>

<form action= "P15_Section6Publication&Dissemination.php">
  <div class="container">
    <label for="apn"><b>Will research participants receive any payments, reimbursement of expenses or any other benefits or incentives for taking part in this research?</b></label>
    <br><input type="radio" id="yes1" name="answer1" onclick="manageTextArea(true, 'answerarea1');" value="Yes">
        <label for="yes1">Yes, give details</label><br>
        <input type="radio" id="no1" name="answer1" onclick="manageTextArea(false, 'answerarea1');" value="No">
        <label for="no1">No</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea1"></textarea>

    <br>

    <label for="apn"><b>Will individual researchers receive any personal payment over and above normal salary, or any other benefits or incentives, for taking part in this research?  (If ‘yes’, please give details)</b></label>
    <br><input type="radio" id="yes2" name="answer2" onclick="manageTextArea(true, 'answerarea2');" value="Yes">
        <label for="yes2">Yes, give details</label><br>
        <input type="radio" id="no2" name="answer2" onclick="manageTextArea(false, 'answerarea2');" value="No">
        <label for="no2">No</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea2"></textarea>

    <br>

    <label for="apn"><b>Does the Chief Investigator or any other investigator/collaborator have any direct personal involvement (e.g. financial, share holding, personal relationship, etc) in the organisations sponsoring or funding the research that may give rise to a possible conflict of interest?</b></label>
    <br><input type="radio" id="yes3" name="answer3" onclick="manageTextArea(true, 'answerarea3');" value="Yes">
        <label for="yes3">Yes, give details</label><br>
        <input type="radio" id="no3" name="answer3" onclick="manageTextArea(false, 'answerarea3');" value="No">
        <label for="no3">No</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea3"></textarea>


  <div class="pageButtons">
    <a href="P13_Section4Confidentiality.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Next</button>
  </div>
</div>

</form>
</body>
</html>


<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>
