<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 3: Recruitment and informed consent
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active"></span>
      <span class="dash active"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
    </div>

<form action= "P13_Section4Confidentiality.php">
  <div class="container">
    <label for="apn"><b>How and by whom will potential participants, records or samples be identified?</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>Will this involve reviewing or screening identifiable personal information of potential participants or any other person?</b></label>
    <br><input type="radio" id="yes1" name="answer1" onclick="manageTextArea(true, 'answerarea1');" value="Yes">
        <label for="yes1">Yes, give details</label><br>
        <input type="radio" id="no1" name="answer1" onclick="manageTextArea(false, 'answerarea1');" value="No">
        <label for="no1">No</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea1"></textarea>

    <br>

    <label for="apn"><b>Has prior consent been obtained or will it be obtained for access to identifiable personal information?</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>Will you obtain informed consent from or on behalf of research participants?</b></label>
    <br><input type="radio" id="yes2" name="answer2" onclick="manageTextArea(true, 'answerarea2');" value="Yes">
        <label for="yes2">Yes, please give details</label><br>
        <input type="radio" id="no2" name="answer2" onclick="manageTextArea(true, 'answerarea2');" value="No">
        <label for="no2">No, please explain why not</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea2"></textarea>

    <br>

    <label for="apn"><b>Will you record informed consent in writing?</b></label>
    <br><input type="radio" id="yes3" name="answer3" onclick="manageTextArea(false, 'answerarea3');" value="Yes">
        <label for="yes3">Yes</label><br>
        <input type="radio" id="no3" name="answer3" onclick="manageTextArea(true, 'answerarea3');" value="No">
        <label for="no3">No, how will it be recorded?</label><br>
    <textarea rows="10" cols="30" wrap="physical" id="answerarea3"></textarea>

    <br>

    <label for="apn"><b>How long will you allow potential participants to decide whether or not to take part?</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>What arrangements have been made for persons who might not adequately understand verbal explanations or written information given in English, or have special communication needs?  (eg,  translation, use of interpreters?)</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>If no arrangements will be made, explain the reasons (eg, resource constraints)</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

  <div class="pageButtons">
    <a href="P11_Section2Risk&EthicalIssues.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Next</button>
  </div>
</div>

</form>
</body>
</html>

<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>

