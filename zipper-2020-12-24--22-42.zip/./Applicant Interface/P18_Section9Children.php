<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 9: Children
  </h1>

    <div style="text-align:center;margin-top:30px;">
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish"></span>
      <span class="dash active finish"></span>
      <span class="step active finish" ></span>
      <span class="dash active finish"></span>
      <span class="step active" ></span>
      <span class="dash active"></span>
      <span class="step" ></span>
      <span class="dash"></span>
      <span class="step" ></span>
    </div>

<form action= "P19_Section10ParticipantsUnableToConsentForThemselves.php">
  <div class="container">

    <label for="apn"><b>Do you plan to include any participants who are children under 16?  (If no, go to next section)</b></label>
    <br><input type="radio" id="yes1" name="answer1" value="Yes">
        <label for="yes1">Yes</label><br>
        <input type="radio" id="no1" name="answer1" value="No">
        <label for="no1">No</label><br>

    <br>

    <label for="apn"><b>Please specify the potential age range of children under 16 who will be included and give reasons for carrying out the research with this age group</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>Please describe the arrangements for seeking informed consent from a person with parental responsibility and/or from children able to give consent for themselves</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

    <label for="apn"><b>If you intend to provide children under 16 with information about the research and seek their consent or agreement, please outline how this process will vary according to their age and level of understanding</b></label>
    <textarea rows="10" cols="30" wrap="physical"></textarea>

    <br>

  <div class="pageButtons">
    <a href="P17_Section8InsuranceIndemnity.php" class="button">Previous</a>
    <button type="submit" class="nextbtn1">Next</button>
  </div>
</div>

</form>
</body>
</html>

<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>

