<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 4: Research Checklist (Part A)
  </h1>

  <div style="text-align:center;margin-top:30px;">
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active "></span>

    <span class="dash active"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>
  </div>

<form action= "P6_Section4_PartB.php">
  <div class="container">

      <table>
      <tr>
        <th>Question No.</th>
        <th>A) Research that may need to be reviewed by an NHS Research Ethics Committee, the Social Care Research Ethics Committee (SCREC) or other external ethics committee (if yes, please give brief details as an annex)</th>
        <th>YES</th>
        <th>NO</th>
      </tr>
      <tr>
        <td style="width10%">Question 1</td>  
        <td>Will the study involve recruitment of patients through the NHS or the use of NHS patient data or samples?</td>
        <td><input type="radio" name="Aq1" value="yes"></td>
        <td><input type="radio" name="Aq1" value="no"></td>
      </tr>
      <tr>
        <td>Question 2</td> 
        <td>Will the study involve the collection of tissue samples (including blood, saliva, urine, etc.) or other biological samples from participants, or the use of existing samples?</td>
        <td><input type="radio" name="Aq2" value="yes"></td>
        <td><input type="radio" name="Aq2" value="no"></td>
      </tr>
      <tr>
          <td>Question 3</td> 
        <td>Will the study involve participants, or their data, from adult social care, including home care, or residents from a residential or nursing care home?</td>
        <td><input type="radio" name="Aq3" value="yes"></td>
        <td><input type="radio" name="Aq3" value="no"></td>
      </tr>
      <tr>
          <td>Question 4</td> 
        <td>Will the study involve research participants identified because of their status as relatives or carers of past or present users of these services? </td>
        <td><input type="radio" name="Aq4" value="yes"></td>
        <td><input type="radio" name="Aq4" value="no"></td>
      </tr>
      <tr>
          <td>Question 5</td> 
        <td>Does the study involve participants aged 16 or over who are unable to give informed consent (e.g. people with learning disabilities or dementia)?</td>
        <td><input type="radio" name="Aq5" value="yes"></td>
        <td><input type="radio" name="Aq5" value="no"></td>
      </tr>
      <tr>
          <td>Question 6</td>
        <td>Is the research a social care study funded by the Department of Health?</td>
        <td><input type="radio" name="Aq6" value="yes"></td>
        <td><input type="radio" name="Aq6" value="no"></td>
      </tr>
      <tr>
          <td>Question 7</td>
        <td>Is the research a health-related study involving prisoners?</td>
        <td><input type="radio" name="Aq7" value="yes"></td>
        <td><input type="radio" name="Aq7" value="no"></td>
      </tr>
      <tr>
          <td>Question 8</td>
        <td>Is the research a clinical investigation of a non-CE Marked medical device, or a medical device which has been modified or is being used outside its CE Mark intended purpose, conducted by or with the support of the manufacturer or another commercial company to provide data for CE marking purposes? (a CE mark signifies compliance with European safety standards)</td>
        <td><input type="radio" name="Aq8" value="yes"></td>
        <td><input type="radio" name="Aq8" value="no"></td>
      </tr>
      <tr>
          <td>Question 9</td>
        <td>Is the research a clinical trial of an investigational medicinal product or a medical device?</td>
        <td><input type="radio" name="Aq9" value="yes"></td>
        <td><input type="radio" name="Aq9" value="no"></td>
      </tr>
    </table>

    <div class="pageButtons">
      <a onclick="saveData('P4_Section3Declaration&Signatures.php')" class="button">Previous</a>
      <button type="submit" class="nextbtn1">Next</button>
    </div>
</div>
</form>
</body>
</html>

<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>

