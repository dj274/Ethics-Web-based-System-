<?php
session_start();
$ApplicationID = $_SESSION["ApplicationID"];
?>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>
<title>
Form
</title>

</head>

<body>

  <h1>
    Section 3: Declaration
  </h1>

  <div style="text-align:center;margin-top:30px;">
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active"></span>
    <span class="dash active"></span>
    <span class="step"></span>

    <span class="dash"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>
    <span class="dash"></span>
    <span class="step"></span>
  </div>

<form action="../PHP/AddSupervisor.php" method="post">
  <div class="container">
    <p>Please note that it is your responsibility to follow, and to ensure that, all researchers involved with your project follow accepted ethical practice and appropriate professional ethical guidelines in the conduct of your study.  You must take all reasonable steps to protect the dignity, rights, safety and well-being of participants. This includes providing participants with appropriate information sheets, ensuring informed consent and ensuring confidentiality in the storage and use of data.</p>
    <hr>
    <br>
    <table>
      <tr>
      </tr>
      <tr>
        <td>I agree with the terms and conditions</td>
        <td><input type= "checkbox" name="Terms" id="agreeterms:"  onclick="currCheck(event)"></td>
      </tr>
    </table>
    <br>
    <br>
    <label for="supname"><b>Supervisor Name:</b</label>
    <input type= "text" placeholder="Supervisor Name..." name="SupervisorName" id="supervisor name" required>

    <label for="supname"><b>Supervisor Email:</b</label>
    <input type= "text" placeholder="Supervisor Email..." name="SupervisorEmail" id="supervisor email" required>

    <div class="pageButtons">
      <a onclick="saveData('P3_Section2ApplicantDetails.php')" class="button">Previous</a>
      <button type="submit" class="nextbtn1">Add other Supverisor</button>
      <a class="button" onclick="clearInputs()">Next</a>
    </div>

</div>
</form>
</body>
</html>


<?php
$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM Section3_Declaration WHERE ApplicationID=" . $ApplicationID . " ORDER BY ApplicationID ASC";

if (mysqli_query($conn, $sql)) {
  $result = mysqli_query($conn, $sql);


} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>

<table class="supervisors">
  <tr>
    <th>ID</th>
    <th>Supervisor(s) Name</th>
    <th>Supervisor(s) Email</th>
    <th>Delete</th>
  </tr>
      
<?php 

    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>". $row["SupervisorID"]."</td>";
        echo "<td>". $row["SupervisorName"]."</td>";
        echo "<td>". $row["SupervisorEmail"]."</td>";
        
        $nextPage = urlencode("Applicant Interface/P4_Section3Declaration&Signatures.php");
        
        
        echo "<td><a href='../PHP/DeleteSupervisor.php?id=".$row["SupervisorID"]."&next=$nextPage'> <img alt='https://www.flaticon.com/free-icon/delete_1345874?term=delete&page=1&position=3&related_item_id=1345874' src='https://www.flaticon.com/svg/static/icons/svg/1345/1345874.svg' width='20' height='20'></a></td>";
    }
?>

</table>
</body>
</html>