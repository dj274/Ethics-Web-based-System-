<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="../style.css">
    <script src="../scripts.js"></script>

<title>
Form
</title>

</head>

<body>

  <h1>
    Section 4: Research Checklist (Part D)
  </h1>

  <div style="text-align:center;margin-top:30px;">
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>

    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active finish"></span>
    <span class="dash active finish"></span>
    <span class="step active"></span>
  </div>

<form action= "/action_page.php">
  <div class="container">

    <table>
      <tr>
        <th>Question</th>
        <th>D) Prevent Agenda</th>
        <th>YES</th>
        <th>NO</th>
      </tr>
      <tr>
          <td>1</td>
        <td>Does the research have the potential to radicalise people who are vulnerable to supporting terrorism or becoming terrorists themselves?
        </td>
        <td><input type="checkbox" id="1" name="yes1" value="yes" onclick="currCheck(event)"required></td>
        <td><input type="checkbox" id="1" name="no1" value="no" onclick="currCheck(event)"required></td>
      </tr>
    </table>

    <div class="pageButtons">
      <a onclick="saveData('P7_Section4_PartC.php')" class="button">Previous</a>
      <button type="submit" class="nextbtn1">Next</button>
    </div>
</div>

</form>
</body>
</html>

<?php

$servername = "localhost";
$username = "id15722548_app21";
$password = "Dhvd202!2334";
$database = "id15722548_applicant";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";


$ProjectTitle = $_POST['ProjectTitle'];
$PlannedStartDate = $_POST['PlannedStartDate'];
$PlannedEndDate = $_POST['PlannedEndDate'];
$Funder = $_POST['Funder'];


$sql = "INSERT INTO Section1_Project_Details (ProjectTitle, PlannedStartDate, PlannedEndDate, Funder)
VALUES ('$ProjectTitle', '$PlannedStartDate', '$PlannedEndDate', '$Funder')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>
